import javax.servlet.http.HttpServlet;

import com.it3030.HelthCare.AppointResource;

@WebServlet("/AppoinmentAPI")
public class AppoinmentAPI extends HttpServlet{
	
	private static final long SerialVersionUID =1L;
	
	AppointResource appobj = new AppointResource();
	
	public AppoinmentAPI()
	
	{
		
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse resonse) throws ServletException, IOException
	{
		
		
	}
	
	
	
	
}